package AimsProject.Src.Media;

interface Playable {
    public void play();
}

